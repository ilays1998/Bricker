package src.brick_strategies;

public enum BrickStrategy {
    REMOVE_BRICK_STRATEGY,
    DOUBLE_BEHAVIOR,
    APPEND_PADDLE_TEMPORARY,
    CHANGE_CAMERA,
    MORE_LIFE,
    ADD_PUCK
}

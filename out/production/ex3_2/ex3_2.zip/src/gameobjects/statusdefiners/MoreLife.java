package src.gameobjects.statusdefiners;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.GraphicLifeCounter;

public class MoreLife extends StatusDefiners{
    private Vector2 dimension;
    private Renderable lifeImage;
    private GameObjectCollection gameObjectCollection;
    private Vector2 windowDimensions;
    private Counter livesCounter;
    private int distanceFromSide;

    public MoreLife(Vector2 topLeftCorner, Vector2 dimension,
                    Renderable lifeImage, Vector2 center, float speed,
                    GameObjectCollection gameObjectCollection,
                    Vector2 windowDimensions, Counter livesCounter,
                    int distanceFromSide) {
        super(topLeftCorner, dimension,
                lifeImage, center, speed, gameObjectCollection, windowDimensions);
        this.dimension = dimension;
        this.lifeImage = lifeImage;
        this.gameObjectCollection = gameObjectCollection;
        this.windowDimensions = windowDimensions;
        this.livesCounter = livesCounter;
        this.distanceFromSide = distanceFromSide;
    }

    @Override
    protected void collisionBehavior(GameObject other) {
        if (livesCounter.value() > 3)
            return;
        livesCounter.increment();
        GameObject graphicLife = new GraphicLifeCounter(Vector2.ZERO, dimension,
                livesCounter, lifeImage, gameObjectCollection, livesCounter.value() - 1,
                distanceFromSide, windowDimensions);

        gameObjectCollection.addGameObject(graphicLife, Layer.BACKGROUND);
    }
}

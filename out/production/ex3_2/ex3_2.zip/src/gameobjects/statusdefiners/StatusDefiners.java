package src.gameobjects.statusdefiners;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import src.gameobjects.Paddle;
import src.gameobjects.PaddleTemporary;

public abstract class StatusDefiners extends GameObject {

    private static final float SPEED = 100;
    private Vector2 dimension;
    private GameObjectCollection gameObjectCollection;
    private Vector2 windowDimensions;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public StatusDefiners(Vector2 topLeftCorner, Vector2 dimension,
                          Renderable renderable,
                          Vector2 center,
                          float speed, GameObjectCollection gameObjectCollection,
                          Vector2 windowDimensions) {
        super(topLeftCorner, dimension, renderable);
        this.dimension = dimension;
        this.gameObjectCollection = gameObjectCollection;
        this.windowDimensions = windowDimensions;
        this.setCenter(center);
        this.setVelocity(Vector2.DOWN.mult(speed));
    }

    public StatusDefiners(Vector2 topLeftCorner, Vector2 dimention,
                          Renderable renderable,
                          Vector2 center, GameObjectCollection gameObjectCollection,
                          Vector2 windowDimensions) {
        super(topLeftCorner, dimention, renderable);
        this.dimension = dimention;
        this.gameObjectCollection = gameObjectCollection;
        this.windowDimensions = windowDimensions;
        this.setCenter(center);
        this.setVelocity(Vector2.DOWN.mult(SPEED));
    }

    @Override
    public boolean shouldCollideWith(GameObject other)
    {
        return (other instanceof Paddle && !(other instanceof PaddleTemporary));
    }

    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        collisionBehavior(other);
        gameObjectCollection.removeGameObject(this);
    }

    protected abstract void collisionBehavior(GameObject other);

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if (this.getDimensions().y() > windowDimensions.y())
            gameObjectCollection.removeGameObject(this);
    }
}
